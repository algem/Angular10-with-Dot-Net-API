import { Component, OnInit } from '@angular/core';
import { SharedService} from 'src/app/shared.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-show-emp',
  templateUrl: './show-emp.component.html',
  styleUrls: ['./show-emp.component.css']
})
export class ShowEmpComponent implements OnInit {
  

  constructor(private service:SharedService) { }

  EmployeeList:any=[];
  PhotoFilePath!: string;
   ModalTitle!: string;
   ActivateAddEditEmpComp:boolean=false;
   emp:any;
   searchText: string = '';
   selectedColumn: string = "EmployeeId";
   

   config = {
    id: 'custom',
    itemsPerPage: 5,
    currentPage: 1,
    totalItems: this.EmployeeList.count
  };

  ngOnInit(): void {
    this.refreshEmpList('');
    
  }

  onChange(event:any){
    if (event.value) {
      this.selectedColumn = event.value;
    } 
  }

  searchTextClick(searchText: any){
    this.refreshEmpList(searchText);
  }


  addClick(){
    this.emp ={
      EmployeeId:0,
      EmployeeName:"",
      Department:"",
      DateOfJoining:"",
      PhotoFileName:""
    }
    this.ModalTitle="Add Employee";
    this.ActivateAddEditEmpComp = true;
  }

  editClick(item: any){
    console.log(item);
    this.emp = item;
    this.ModalTitle ="Edit Employee";
    this.ActivateAddEditEmpComp = true;
  }

  deleteClick(item:any){
    this.emp = item;
    Swal.fire({
    title: 'Are you sure?',
    text: 'You will not be able to recover this record!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'No, keep it',
    }).then((result) => {
      if (result.isConfirmed) {
        this.service.deleteEmployee(item.EmployeeId).subscribe(data=>{                
          this.refreshEmpList('');         
        })
      } else if (result.isDismissed) {
        this.closeClick();
      }
    })
  }

  closeClick(){
    this.ActivateAddEditEmpComp = false;
    this.refreshEmpList('');
  }

  refreshEmpList(searchText: string){  
    
    this.service.getFilteredEmpList(this.selectedColumn, searchText).subscribe(data=>{
      this.EmployeeList = data;
      this.PhotoFilePath=this.service.PhotoUrl;
    })  
  }


  refreshEmpList_Old(searchText: string){  
    this.service.getEmpList().subscribe(data=>{
      if(searchText){     
        let filterResult: any = this.filterByString(data,searchText);
        data = filterResult;
      }
      this.EmployeeList = data;
      this.PhotoFilePath=this.service.PhotoUrl;
    })  
  }
  
  filterByString(data: any[], s: any) { 
    if (this.selectedColumn == "EmployeeName") {
      return data.filter(e => e.EmployeeName.toLowerCase().includes( s.toLowerCase().toString()));
    } else if (this.selectedColumn == "Department") {
      return data.filter(e => e.Department.toLowerCase().includes( s.toLowerCase().toString()));
    } else if  (this.selectedColumn == "DateOfJoining") {
      return data.filter(e => e.DateOfJoining.toString().includes( s.toLowerCase().toString()));
      }else{
        return data.filter(e => e.EmployeeId.toString().includes( s.toLowerCase().toString()));
      }  
  }
}
