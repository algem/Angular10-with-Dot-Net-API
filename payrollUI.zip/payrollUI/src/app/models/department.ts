export class Department {
    'DepartmentID': bigint;
    'DEpartmentName': string;
}
